# 第十六段 再現パッケージ

2026-11-16 JST。Python3標準ライブラリだけで動く。ネットワーク不要。

実行：`python3 code/run_all.py`

- 日本語完成報告と次の未解決義務：ルートの2つのMarkdown。
- `code/proof_engine.py`：内容型付き1穴・2穴の直接代入のみを記録する生成器基盤。
- `code/noncyclic_ab.py`：非巡回AB16の全称証明テンプレートの数値具体化。
- `code/component_tree.py`：交錯・入れ子の二成分Transport、多重集合合成、実際の第十五段木。
- `code/order_normalization.py`：余剰aによる順序相正規化ON。
- `code/independent_replay.py`：上記生成器をimportしない別実装の証明書replayと有限言語の完全分布検査。
- `code/source_audit.py`：固定GitHub commitのblob SHAと既存SHA-256一覧の検査。
- `legacy/round15_check.py`：外部既存コードを原バイトで同梱したもの。新証明の根拠としてではなく再現・陰性対照用に使用。
- `certificates/`：種集合と全ステップを明記した11証明書。全て実行済み。
- `logs/`：各プログラムの完全stdout、stderr、終了コード。
- `execution_manifest.json`：実行環境とコマンド、終了結果。
- `source_manifest.json`：取得commit、各資料のblob SHA、SHA-256。
- `sources/`：実際に取得した原資料の読取り専用スナップショット。原文献・旧報告の過去の誤主張もそのまま含むため、数学的状態は最新監査と今回の報告を優先する。
- `SHA256SUMS.txt`：同梱ファイルのハッシュ（この一覧自体を除く）。

全計算は決定的。乱数seedなし、閉包探索なし、cap/truncatedなし。語長capを設けず有限証明テンプレートを完走した。一般手証明の成立と有限実行の範囲は報告で区別している。

GitHubと論文本文は未変更。一般AB、一般P_tree、U、正式LG境界は未解決。
