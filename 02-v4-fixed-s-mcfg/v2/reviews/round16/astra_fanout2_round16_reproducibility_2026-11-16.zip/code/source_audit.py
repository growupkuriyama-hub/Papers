"""Verify the fetched, read-only GitHub snapshots and the archived checksums."""
import pathlib,hashlib,json

root=pathlib.Path(__file__).resolve().parents[1]
src=root/'sources'; manifest=json.loads((src/'fetched_manifest.json').read_text())
for entry in manifest['files']:
    p=src/entry['path'];data=p.read_bytes()
    sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert sha==entry['sha'],(str(p),sha,entry['sha'])
    entry['sha256']=hashlib.sha256(data).hexdigest();entry['bytes']=len(data)
    print(entry['path'],entry['sha'],entry['sha256'],'VERIFIED')
archive=src/'reviews'/'round15'
for line in (archive/'SHA256SUMS.txt').read_text().splitlines():
    if not line:continue
    sha,name=line.split()
    p=src/'reviews'/name if name.startswith('astra_') else archive/name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==sha,name
print('Archived Round15 six SHA-256 values: all match')
assert (root/'logs/round15_rerun.stdout').read_bytes()==(archive/'round15_check.log').read_bytes()
print('Round15 stdout: byte-identical to archived log; exit', (root/'logs/round15_rerun.exit').read_text().strip())
(root/'source_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
