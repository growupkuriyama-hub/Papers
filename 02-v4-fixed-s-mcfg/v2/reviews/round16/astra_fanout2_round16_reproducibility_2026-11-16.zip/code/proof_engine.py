"""Primitive content-typed 1/2-hole certificate builder. Standard Python only."""
import json

def fill(e,x):
    return ''.join(e[i]+v for i,v in enumerate(x))+e[-1]

class Proof:
    def __init__(self,N,seed):
        self.N=N; self.seed=sorted(set(seed)); self.known=set(seed); self.steps=[]
    def step(self,x,y,e,f,label=''):
        x,y,e,f=map(tuple,(x,y,e,f))
        assert len(x)==len(y) in (1,2)
        assert all(x) and all(y)
        assert list(map(set,x))==list(map(set,y)),(label,x,y)
        assert len(e)==len(f)==len(x)+1
        assert all(e[1:-1]) and all(f[1:-1]),(label,e,f)
        for w in (fill(e,x),fill(e,y),fill(f,x)):
            assert w in self.known,(label,'missing',w)
        w=fill(f,y)
        self.steps.append(dict(x=x,y=y,E0=e,E1=f,out=w,label=label))
        self.known.add(w)
        return w
    def redistribute(self,P,Q,R,i,j,k):
        # P a^i Q a^j R -> P a^k Q a^(i+j-k) R
        assert Q and min(i,j,k,i+j-k)>=1 and i+j<self.N
        return self.step(('a'*i,'a'*j),('a'*k,'a'*(i+j-k)),
                         ('','a','a'*(self.N-1-i-j)),(P,Q,R),'R')
    def commute(self,block,w,pos,right=True,host=None):
        # Move one a right across block, or reverse, at an indicated occurrence.
        x='a'+block; y=block+'a'
        if not right:x,y=y,x
        assert w[pos:pos+len(x)]==x,(block,w,pos,right)
        return self.step((x,),(y,),host,(w[:pos],w[pos+len(x):]),'commute')
    def rot_host(self,K,lam):
        assert 3<=lam<self.N
        # Seed a K a^(lam-1).
        self.redistribute('',K,'',1,lam-1,2)
        return ('a','a'*(lam-2))
    def move_all_right(self,w,blocks,hosts):
        # blocks give a fixed tokenization; a may move over each whole block.
        # Greedily parse a* block a* ... block a*, then commute a's to the end.
        offset=0
        for block in blocks:
            n=0
            while offset+n<len(w) and w[offset+n]=='a':n+=1
            assert w[offset+n:offset+n+len(block)]==block
            for _ in range(n):
                w=self.commute(block,w,offset+n-1,host=hosts[block]); n-=1
            offset+=len(block)
        assert set(w[offset:])<=set('a')
        return w
    def save(self,path,metadata=None):
        with open(path,'w') as f:json.dump(dict(N=self.N,seed=self.seed,steps=self.steps,metadata=metadata or {}),f,indent=2)

def unary_contradiction(p,prefix,e,f):
    assert e!=f and min(e,f)>=1
    lo,hi=sorted((e,f)); gap=hi-lo
    assert 0<gap<p.N
    return p.step(('a'*(gap+1),),('a',),(prefix,'a'*(lo-1)),
                  ('a'*(p.N-gap-1),''),'shorter unary word')
