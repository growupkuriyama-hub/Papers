"""Construct the symbolic AB16 proof at any integer parameters in its domain."""
from proof_engine import Proof,unary_contradiction

B='bbcc'; C='bcbc'

def build(N,d1,d2,xyz=None,pads=None):
    assert d1>0 and d2>0 and N>=6*max(d1,d2)+1
    l1,l2=N-d1,N-d2; t=N-d1-d2; s=d1-d2
    xyz=xyz or (1,1,t-2); pads=pads or (1,1)
    x,y,z=xyz; p1,p2=pads
    assert min(x,y,z)>=0 and x+y+z==t
    assert 1<=p1<l1 and 1<=p2<l2
    host='a'*x+B+'a'*y+C+'a'*z
    p=Proof(N,['a'*N,'a'*p1+B+'a'*(l1-p1),
               'a'*p2+C+'a'*(l2-p2),host])
    for K,lam,left in [(B,l1,p1),(C,l2,p2)]:
        p.redistribute('',K,'',left,lam-left,1)
    hosts={B:p.rot_host(B,l1),C:p.rot_host(C,l2)}
    p.move_all_right(host,[B,C],hosts)
    # Move the a at left of each singleton to the right.
    for K,lam in [(B,l1),(C,l2)]:
        p.commute(K,'a'+K+'a'*(lam-1),0,host=hosts[K])
    i=1+max(0,l2-l1); j=i+l1-l2
    p.step((C+'a'*i,),(B+'a'*j,),('', 'a'*(l2-i)),
           (B,'a'*(t-i)),'replace C by B')
    # Right-hand frame exchange (u,a^i) with frame b _ c.
    def flip(w,pos,up):
        old,new=('bc','cb') if up else ('cb','bc')
        lam,lam2=(l1,l2) if up else (l2,l1)
        delta=lam2-lam
        i=1+max(0,-delta); j=i+delta
        K,K2=(B,C) if up else (C,B)
        # Singleton exponent split needed for the shared frame.
        for core,total,tail in [(K,lam,i),(K2,lam2,j)]:
            p.redistribute('',core,'',1,total-1,total-tail)
        e=('', '', '')
        e=('a'*(lam-i)+'b','c','')
        k=len(w.rstrip('a')); exp=len(w)-k
        assert w[pos:pos+2]==old and exp>=i
        Q=w[pos+2:k]
        assert Q
        return p.step((old,'a'*i),(new,'a'*j),e,
                      (w[:pos],Q,'a'*(exp-i)),'frame '+old+'->'+new)
    w=B+B+'a'*(N-2*d1)
    for pos in [3,2,4,3]:w=flip(w,pos,False)
    E=N-6*d1+4*d2
    assert w=='bbbbcccc'+'a'*E
    # This is a literal equality at E0, not a guessed permutation rule.
    power_host=('','b','cccc'+'a'*E)
    for pos in [3,2,1]:w=flip(w,pos,True)
    T=E+3*s
    assert w=='bcbbbccc'+'a'*T
    w0=p.step(('b','bb'),('bb','b'),power_host,
              ('','c','bccc'+'a'*T),'b-power transfer')
    assert w0=='bbcbbccc'+'a'*T
    w1=flip(w,1,False)
    assert w1=='bbcbbccc'+'a'*(T-s)
    if d1!=d2:
        assert unary_contradiction(p,'bbcbbccc',T,T-s)=='a'*(N-abs(s))
    return p

if __name__=='__main__':
    import pathlib
    root=pathlib.Path(__file__).resolve().parents[1]
    cases=steps=0
    for N in range(7,62):
        for d1 in range(1,(N-1)//6+1):
            for d2 in range(1,(N-1)//6+1):
                p=build(N,d1,d2); cases+=1; steps+=len(p.steps)
    boundary=0
    for d1,d2 in [(1,2),(2,1),(1,3),(3,1),(2,2)]:
        N=6*max(d1,d2)+1;t=N-d1-d2
        for x in range(t+1):
            for y in range(t-x+1):
                build(N,d1,d2,(x,y,t-x-y),(N-d1-1,N-d2-1));boundary+=1
    p=build(13,2,1)
    p.save(root/'certificates'/'AB16_N13_d2_d1.json',{'claim':'contradiction','d1':2,'d2':1})
    q=build(19,1,3)
    q.save(root/'certificates'/'AB16_N19_d1_d3.json',{'claim':'contradiction; a-tail can exceed N','d1':1,'d2':3})
    print('AB16 all parameters N=7..61:',cases,'certificates;',steps,'primitive steps PASS')
    print('AB16 all additive host splits for 5 boundary pairs:',boundary,'PASS')
    print('No closure search, no cap, no randomness. These are proof-instance checks, not language enumeration.')
