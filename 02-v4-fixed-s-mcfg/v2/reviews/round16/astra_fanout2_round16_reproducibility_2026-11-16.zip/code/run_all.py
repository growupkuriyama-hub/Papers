"""Run all recorded checks with stdout, stderr and return codes retained."""
import pathlib,subprocess,sys,json,platform,hashlib
root=pathlib.Path(__file__).resolve().parents[1]
(root/'logs').mkdir(exist_ok=True)
jobs=[('round15_rerun','legacy/round15_check.py'),
      ('source_audit','code/source_audit.py'),
      ('noncyclic_ab','code/noncyclic_ab.py'),
      ('component_tree','code/component_tree.py'),
      ('order_normalization','code/order_normalization.py'),
      ('independent_replay','code/independent_replay.py')]
records=[]
for name,script in jobs:
    proc=subprocess.run([sys.executable,str(root/script)],capture_output=True,cwd=root)
    (root/'logs'/f'{name}.stdout').write_bytes(proc.stdout)
    (root/'logs'/f'{name}.stderr').write_bytes(proc.stderr)
    (root/'logs'/f'{name}.exit').write_text(str(proc.returncode)+'\n')
    records.append(dict(name=name,command=['python3',script],exit_code=proc.returncode,
                        stdout_bytes=len(proc.stdout),stderr_bytes=len(proc.stderr)))
    print(name,'exit',proc.returncode,'stdout',len(proc.stdout),'stderr',len(proc.stderr),flush=True)
    if proc.returncode:raise SystemExit(proc.returncode)
(root/'execution_manifest.json').write_text(json.dumps(dict(python=platform.python_version(),
    jobs=records,random_seed=None,closure_search=False,truncated=False),indent=2)+'\n')
print('All executed checks finished successfully.')
