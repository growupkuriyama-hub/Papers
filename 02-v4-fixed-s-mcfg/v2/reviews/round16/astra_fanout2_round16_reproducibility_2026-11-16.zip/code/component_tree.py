"""Direct two-component composition certificates, without connected kernels."""
from proof_engine import Proof,unary_contradiction

def canon(N,U):
    p,q,d=U; A=N-d
    assert p>0 and q>0 and d>0 and A>=4
    return 'a'+'b'*p+'a'+'c'*q+'a'*(A-2)

class ComponentProof:
    def __init__(self,N,units,seedpair,mode='cross',gaps=None,singletons=None):
        self.N=N; self.units=units; self.hosts={}; self.known_units=set()
        B,C=seedpair; p,q,d=B; r,s,e=C
        A=N-d-e; assert A>=1
        tokens=['b'*p,'b'*r,'c'*q,'c'*s] if mode=='cross' else ['b'*p,'b'*r,'c'*s,'c'*q]
        gaps=gaps if gaps is not None else ([1,0,A-2,0,1] if A>=2 else [1,0,0,0,0])
        assert len(gaps)==5 and min(gaps)>=0 and sum(gaps)==A
        seed=''.join('a'*gaps[i]+z for i,z in enumerate(tokens))+'a'*gaps[-1]
        solo=[canon(N,U) for U in units]
        if singletons is not None:
            solo=[]
            for U,(l,g,r0) in zip(units,singletons):
                pp,qq,dd=U
                assert min(l,g,r0)>=1 and l+g+r0==N-dd
                solo.append('a'*l+'b'*pp+'a'*g+'c'*qq+'a'*r0)
        self.p=Proof(N,['a'*N,seed]+solo)
        if singletons is not None:
            for U,(l,g,r0) in zip(units,singletons):
                pp,qq,dd=U;b='b'*pp;cc='c'*qq
                self.p.redistribute('',b+'a'*g+cc,'',l,r0,1)
                self.p.redistribute('a'+b,cc,'',g,l+r0-1,1)
        for U in units:self.register(U)
        self.reposition(seed,tokens,[0,0,0,0,A])
        if A>=3:self.reposition(seed,tokens,[1,0,1,0,A-2])
        self.seedpair=seedpair
        assert 'b'*(p+r)+'c'*(q+s)+'a'*A in self.p.known
    def distribution(self,U,l,g,r):
        p,q,d=U; A=self.N-d
        assert l+g+r==A and min(l,g,r)>=1
        b,c='b'*p,'c'*q
        self.p.redistribute('',b+'a'+c,'',1,A-2,l)
        return self.p.redistribute('a'*l+b,c,'',1,A-l-1,g)
    def register(self,U):
        if U in self.known_units:return
        p,q,d=U; A=self.N-d; b,c='b'*p,'c'*q
        assert canon(self.N,U) in self.p.known
        self.distribution(U,2,1,A-3)
        self.distribution(U,1,2,A-3)
        self.hosts[b]=('a','a'+c+'a'*(A-3))
        self.distribution(U,A-3,2,1)
        self.distribution(U,A-3,1,2)
        self.hosts[c]=('a'*(A-3)+b+'a','a')
        self.known_units.add(U)
    def reposition(self,w,tokens,target):
        A=w.count('a'); assert sum(target)==A
        w=self.p.move_all_right(w,tokens,self.hosts)
        g=[0]*len(tokens)+[A]
        for j,count in enumerate(target[:-1]):
            for _ in range(count):
                for k in range(len(tokens)-1,j-1,-1):
                    offset=sum(g[:k+1])+sum(map(len,tokens[:k]))
                    assert g[k+1]>0
                    w=self.p.commute(tokens[k],w,offset,right=False,host=self.hosts[tokens[k]])
                    g[k+1]-=1;g[k]+=1
        assert g==target
        return w
    def replace(self,X,Y,R):
        # Known component sum X+R -> Y+R; keep both component blocks in place.
        p,q,d=X; p2,q2,d2=Y; r,s,e=R
        A=self.N-d-e; A2=self.N-d2-e
        assert min(A,A2)>=1
        self.register(X);self.register(Y);self.register(R)
        old='b'*(p+r)+'c'*(q+s)+'a'*A
        tokens=['b'*p,'b'*r,'c'*q,'c'*s]
        self.reposition(old,tokens,[0,0,0,A,0])
        i=A;j=A2
        # e is the retained unit's positive deficit. No third hole is used.
        self.reposition(canon(self.N,X),['b'*p,'c'*q],[e-1,1,i])
        self.reposition(canon(self.N,Y),['b'*p2,'c'*q2],[e-1,1,j])
        w=self.p.step(('b'*p,'c'*q+'a'*i),
                      ('b'*p2,'c'*q2+'a'*j),
                      ('a'*(e-1),'a',''),('','b'*r,'c'*s),
                      'component replacement')
        tokens=['b'*p2,'b'*r,'c'*q2,'c'*s]
        flat=self.reposition(w,tokens,[0,0,0,0,A2])
        if A2>=3:self.reposition(w,tokens,[1,0,1,0,A2-2])
        return flat
    def pair(self,U,V):
        B,C=self.seedpair
        if B[2]>C[2]:B,C=C,B
        assert U[2]<= (self.N-1)//2 and V[2]<=(self.N-1)//2
        self.replace(C,U,B)
        self.replace(B,V,U)
        return (U[0]+V[0],U[1]+V[1],U[2]+V[2])
    def compose(self,items):
        assert items and sum(U[2] for U in items)<=self.N-4
        if len(items)==1:return items[0]
        if len(items)==2:return self.pair(*items)
        M=self.compose(items[:-1]);J=items[0];last=items[-1]
        self.pair(J,last)
        self.register(M)
        self.replace(J,M,last)
        return (M[0]+last[0],M[1]+last[1],M[2]+last[2])

if __name__=='__main__':
    import pathlib
    root=pathlib.Path(__file__).resolve().parents[1]
    cases=steps=0
    for mode in ['cross','nest']:
        for N in [19,25,37]:
            for d1,d2 in [(2,3),(3,5),(4,8)]:
                U=(1,1,d1);V=(2,2,d2)
                if max(d1,d2)>(N-4)//2:continue
                c=ComponentProof(N,[U,V],(U,U),mode)
                M=c.compose([U,U])
                if M[2]!=V[2]:
                    unary_contradiction(c.p,'abbacc',N-M[2]-2,N-V[2]-2)
                cases+=1;steps+=len(c.p.steps)
                if N==25 and d1==3 and d2==5:
                    c.p.save(root/'certificates'/('P2_'+mode+'_nonlinear.json'),
                             {'mode':mode,'claim':'2*(1,1,3) versus (2,2,5) impossible'})
    # Three-unit integer relation and true multiplicities.
    for mode in ['cross','nest']:
        U=(1,2,3);V=(2,1,4);W=(3,3,8)
        c=ComponentProof(49,[U,V,W],(U,V),mode)
        M=c.compose([U,U,V,V]);Q=c.compose([W,W])
        assert M[:2]==Q[:2]==(6,6)
        prefix='a'+'b'*6+'a'+'c'*6
        unary_contradiction(c.p,prefix,49-M[2]-2,49-Q[2]-2)
        c.p.save(root/'certificates'/('P2_'+mode+'_multiplicity.json'),
                 {'claim':'2U+2V=2W Parikh, inconsistent deficits force short unary'})
        cases+=1;steps+=len(c.p.steps)
    # A one-a seed, with a large seed unit outside the admissible half-window.
    for mode in ['cross','nest']:
        B=(2,2,8);C=(1,1,4)
        c=ComponentProof(13,[B,C],(B,C),mode)
        M=c.compose([C,C])
        assert M==(2,2,8)
        for w in c.p.known:
            assert w.count('a')+4*w.count('b')==13
            assert w.count('b')==w.count('c')
            assert 'cb' not in w.replace('a','')
        c.p.save(root/'certificates'/('P2_'+mode+'_one_a_seed.json'),
                 {'claim':'seed deficit 8 outside half-window; seed a-budget 1; consistent'})
        cases+=1;steps+=len(c.p.steps)
    # Negative control from Round15: only a small member, to limit certificate size.
    for mode in ['cross','nest']:
        U=(1,1,4);V=(2,2,8)
        c=ComponentProof(19,[U,V],(U,U),mode)
        M=c.compose([U,U,U])
        for w in c.p.known:
            assert w.count('b')==w.count('c')
            assert w.count('a')+4*w.count('b')==19
            assert 'cb' not in w.replace('a','')
        assert M==(3,3,12)
        cases+=1;steps+=len(c.p.steps)
    print('P2 direct component certificates:',cases,';',steps,'primitive steps PASS')
    print('Cross/nest, non-linear pair and multiplicity contradictions, Round15 negative control PASS')
    print('No connected-kernel host constructed or assumed. No closure search, no cap, no randomness.')
    # Exact large tree words audited in Round15, and the parent B2 word.
    for mode,gaps,solos in [
        ('cross',[129,0,385,0,257],[(129,449,321),(129,385,257)]),
        ('nest',[129,0,513,0,129],[(129,641,129),(129,513,129)])]:
        U=(2,2,128);V=(4,4,256)
        c=ComponentProof(1027,[U,V],(U,U),mode,gaps,solos)
        M=c.compose([U,U]);assert M==V
        for w in c.p.known:
            assert w.count('a')+64*w.count('b')==1027
            assert w.count('b')==w.count('c') and 'cb' not in w.replace('a','')
        c.p.save(root/'certificates'/('P2_'+mode+'_R15_tree.json'),
                 {'claim':'actual Round15 tree words; P2 premise and transport control',
                  'N':1027,'theta':97,'short_tuple_B1':[2,2],'short_tuple_B2':[4,4]})
        print('Actual Round15 tree control',mode,len(c.p.steps),'primitive steps PASS')
