"""Independent certificate verifier: no imports from either proof generator."""
import json,pathlib,itertools,runpy
from collections import defaultdict

def plug(context,words):
    result=context[0]
    for i in range(len(words)):result+=words[i]+context[i+1]
    return result

def replay(path):
    data=json.loads(path.read_text()); available=set(data['seed'])
    for number,s in enumerate(data['steps']):
        x=s['x'];y=s['y'];e=s['E0'];f=s['E1']
        assert len(x) in [1,2] and len(x)==len(y)
        assert all(len(v)>0 for v in x+y)
        assert all(sorted(set(v))==sorted(set(w)) for v,w in zip(x,y))
        assert len(e)==len(f)==len(x)+1
        if len(x)==2:assert len(e[1])>0 and len(f[1])>0
        assert plug(e,x) in available,(path,number,'E0x')
        assert plug(e,y) in available,(path,number,'E0y')
        assert plug(f,x) in available,(path,number,'E1x')
        result=plug(f,y);assert result==s['out']
        available.add(result)
    if 'contradiction' in data['metadata'].get('claim','') or 'impossible' in data['metadata'].get('claim','') or 'force short' in data['metadata'].get('claim',''):
        assert any(set(w)=={'a'} and len(w)<data['N'] for w in available)
    return len(data['steps']),max(map(len,available))

def exact_substitution(language):
    distributions=defaultdict(set)
    for word in language:
        n=len(word)
        for i in range(n):
            for j in range(i+1,n+1):
                distributions[(word[i:j],)].add((word[:i],word[j:]))
                for k in range(j+1,n):
                    for l in range(k+1,n+1):
                        distributions[(word[i:j],word[k:l])].add((word[:i],word[j:k],word[l:]))
    witness={};checks=0
    for words,contexts in distributions.items():
        signature=tuple(tuple(sorted(set(w))) for w in words)
        for context in contexts:
            key=(signature,context)
            if key in witness:assert contexts==distributions[witness[key]];checks+=1
            else:witness[key]=words
    return len(distributions),sum(map(len,distributions.values())),checks

if __name__=='__main__':
    root=pathlib.Path(__file__).resolve().parents[1]
    total=0
    for path in sorted((root/'certificates').glob('*.json')):
        steps,maxlen=replay(path);total+=steps
        print(path.name,'steps',steps,'maximum word length',maxlen,'PASS')
    print('Independent replay total primitive steps',total)
    # Only legacy finite-language data is reused; its verifier is not called here.
    legacy=runpy.run_path(str(root/'legacy'/'round15_check.py'),run_name='legacy_data_only')
    for name in ['L40','L67']:
        lang=legacy[name]
        print('INDEPENDENT exact contexts',name,len(lang),exact_substitution(lang),'PASS')
    print('No candidate was omitted in the finite-language checks. No cap, length truncation, or randomness.')
