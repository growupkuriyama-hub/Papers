"""Primitive proof of ordered-phase normalization with one spare a."""
import pathlib
from proof_engine import Proof

def word(blocks,gaps):
    return ''.join('a'*gaps[i]+z for i,z in enumerate(blocks))+'a'*gaps[-1]

def rebalance(p,blocks,gaps,target):
    g=list(gaps);assert min(g+target)>=1 and sum(g)==sum(target)<p.N
    while g!=target:
        donor=next(i for i in range(len(g)) if g[i]>target[i])
        dest=next(i for i in range(len(g)) if g[i]<target[i])
        n=min(g[donor]-target[donor],target[dest]-g[dest]);i,j=sorted((donor,dest))
        w=word(blocks,g)
        left=sum(g[:i])+sum(map(len,blocks[:i]))
        right=sum(g[:j])+sum(map(len,blocks[:j]))
        first=g[i]+(n if i==dest else -n)
        p.redistribute(w[:left],w[left+g[i]:right],w[right+g[j]:],g[i],g[j],first)
        g[donor]-=n;g[dest]+=n
    return word(blocks,g)

def build(blocks,gaps):
    A=sum(gaps);t=len(blocks);assert A>=t+2
    assert all(set(z) in ({'b'},{'c'}) for z in blocks)
    assert 'cb' not in ''.join(blocks)
    N=A+5;start=word(blocks,gaps);p=Proof(N,['a'*N,start]);hosts={}
    for k,z in enumerate(blocks):
        h=[1]*(t+1);h[k]+=A-(t+1)
        w=rebalance(p,blocks,gaps,h)
        h2=h[:];h2[k]-=1;h2[k+1]+=1
        w2=rebalance(p,blocks,h,h2)
        left=sum(h[:k])+sum(map(len,blocks[:k]))
        P=w[:left]+'a'*(h[k]-1)
        right=left+h[k]+len(z)
        Q='a'*h[k+1]+w[right+h[k+1]:]
        assert P+'a'+z+Q==w
        assert P+z+'a'+Q==w2
        hosts[z]=(P,Q)
    flat=p.move_all_right(start,blocks,hosts)
    assert flat==''.join(blocks)+'a'*A
    return p

if __name__=='__main__':
    root=pathlib.Path(__file__).resolve().parents[1]
    cases=steps=0
    for blocks in [['b','b','c','c'],['bb','b','cc'],['b','ccc'],['bb','bb','cc','c','c']]:
        for surplus in range(1,5):
            for reservoir in range(len(blocks)+1):
                gaps=[1]*(len(blocks)+1);gaps[reservoir]+=surplus
                p=build(blocks,gaps);cases+=1;steps+=len(p.steps)
    p=build(['b','b','c','c'],[1,1,2,1,1])
    p.save(root/'certificates'/'P2_order_normalization.json',
           {'claim':'single spare a normalizes mixed-a monochromatic phases'})
    print('Ordered-phase normalization:',cases,'instances;',steps,'primitive steps PASS')
    print('Every a-run remains positive during R; all zeroing uses certified one-hole commutations.')
