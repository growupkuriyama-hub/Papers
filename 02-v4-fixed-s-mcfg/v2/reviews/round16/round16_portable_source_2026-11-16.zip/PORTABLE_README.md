# Round 16 portable source package (compact GitHub archive)

All 9 included Python scripts are byte-identical to the independently repaired source ZIP. No large generated certificates or read-only source snapshots are included.

Run from this extracted directory with Python 3 (standard library only):

    mkdir -p certificates
    python3 code/noncyclic_ab.py
    python3 code/component_tree.py
    python3 code/order_normalization.py
    python3 code/independent_replay.py
    python3 audit_independent_replay.py

These commands regenerate the 11 proof certificates in certificates/ and independently replay their 21,249 primitive steps. They also check the 40/67-word negative controls. The full original `code/run_all.py` cannot run in this compact package because `code/source_audit.py` expects archived sources/ from the complete ZIP; use the five commands above. Large derived JSON certificates may use tens of megabytes of disk space.

The uploaded complete original and repaired ZIPs, together with SHA-256 and the known missing Round-15 checksum file, are documented in the Round-16 GitHub status. Formal proof and peer review are not claimed.
