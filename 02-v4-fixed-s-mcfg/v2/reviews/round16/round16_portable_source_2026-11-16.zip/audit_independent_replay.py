#!/usr/bin/env python3
"""Independent audit replay of Astra round 16 certificates.
This script does not import or execute Astra's proof engine or checker.
"""
from pathlib import Path
import json

def filled(e, words):
    s=e[0]
    for w,r in zip(words,e[1:]):s+=w+r
    return s

def check_one(file):
    d=json.loads(file.read_text()); known=set(d['seed']); n=d['N']
    assert 'a'*n in known
    for i,row in enumerate(d['steps']):
        x,y,e,f=[row[z] for z in ('x','y','E0','E1')]
        assert len(x)==len(y) in (1,2), (file,i,'arity')
        assert len(e)==len(f)==len(x)+1, (file,i,'context length')
        assert all(x+y), (file,i,'empty component')
        assert all(set(v)==set(w) for v,w in zip(x,y)), (file,i,'unequal types')
        if len(x)==2: assert e[1] and f[1], (file,i,'empty middle')
        a,b,c=filled(e,x),filled(e,y),filled(f,x)
        assert a in known and b in known and c in known,(file,i,'missing premise')
        result=filled(f,y)
        assert result==row['out'],(file,i,'wrong conclusion')
        known.add(result)
    label=d.get('metadata',{}).get('claim','')
    if any(s in label for s in ('contradiction','impossible','force short')):
        assert any(0<len(w)<n and set(w)=={'a'} for w in known),(file,'no shorter a-power')
    return len(d['steps']),len(known)

def verify():
    folder=Path(__file__).resolve().parent / 'certificates'
    total=0
    for f in sorted(folder.glob('*.json')):
        n,known=check_one(f);total+=n
        print(f.name,'steps',n,'known',known,'PASS')
    assert total==21249,total
    # Mutation controls independently require illegal steps to be rejected.
    d=json.loads((folder/'AB16_N13_d2_d1.json').read_text())
    first=d['steps'][0]
    for change in ('zero_hole','wrong_typing','unjustified_step'):
        q=json.loads(json.dumps(d));row=q['steps'][0]
        if change=='zero_hole':row['x'][0]=''
        elif change=='wrong_typing':row['y'][0]='c'
        else:row['E1'][0]='c'+'x'
        scratch=folder/('_mutation_'+change+'.json')
        scratch.write_text(json.dumps(q))
        try:
            failed=False
            try:check_one(scratch)
            except AssertionError:failed=True
            assert failed,change
        finally:scratch.unlink()
    print('ALL PASS',total,'steps, three deliberate mutations rejected')

if __name__=='__main__':verify()
