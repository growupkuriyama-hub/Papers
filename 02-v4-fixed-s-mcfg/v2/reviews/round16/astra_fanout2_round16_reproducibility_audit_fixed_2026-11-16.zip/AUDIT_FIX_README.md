# 監査用補完版（元ZIPはそのまま保存）

元ZIPの `sources/reviews/round15/SHA256SUMS.txt` 封入漏れのみを補完しました。
補完ファイルはGitHub固定commit d1718eff64830be0ae6e2483fbeda8a6fe04843dの原本とblob SHA一致。
SHA: 72d0d77ba705a270395c087188f7c17e25a4ff3a

他の元ファイルのバイト列は変更していません。元のSHA256SUMS.txtの59項目は元のままです。

- 元の全検査：`python3 -I code/run_all.py`
- 監査者の独立replay：`python3 -I audit_independent_replay.py`
- 数学監査：`audit_astra_fanout2_round16_independent_2026-11-16.md`

元ZIPは、補完前のままだとsource_auditでFileNotFoundErrorにより停止します。
