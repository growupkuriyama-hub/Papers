# TLCA open-problem explorations — May 2026
Takayuki Kuriyama | AI-assisted research archive

This is an exploratory archive, not a claim to have solved any TLCA open problem. Historical AI-assisted research reports, citations and proof sketches are unverified; later notes supersede earlier speculative claims.

- #18: contextual equivalences, finite-local separation attempts, research prompts and proof sketches. No new characterization of unresolved cases is claimed.
- #24: clarification note v2 describes the I/K collision for a literal individual-arity deed encoding, not a solution to the intended equational problem. Earlier reports are working drafts.
- #26: ordinal assignment, draft note and text representation of the one-page PDF sent to the authors of Barenbaum–Sottile on May 3, 2026. Three readings of 'easy' are distinguished; the decreasing measures are results of Barenbaum–Sottile, not a new solution by Kuriyama.

Other problems were surveyed but no separate substantive artifact was located. Private correspondence is excluded. This is a best-effort recovery, not a guarantee that all historical materials survive. The GitHub edition preserves recovered text (line endings may be normalized); the original #26 PDF is represented by text. The local edition contains the original PDF.
